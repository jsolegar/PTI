# REST API

Alumnos: 

- Jordi Solé García (Grupo 11)
- Víctor Gallego Izquierdo (Grupo 11)

## Objetivos de la práctica

El objetivo de la práctica es la creación de una API Rest básica basada en **Node.js**. Node.js 